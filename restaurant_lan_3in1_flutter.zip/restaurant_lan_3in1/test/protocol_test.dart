import 'package:flutter_test/flutter_test.dart';
import 'package:restaurant_lan_3in1/models/protocol.dart';

void main() {
  test('protocol round trip', () {
    final x = ProtocolMessage(
      type: MessageType.orderCreate,
      requestId: 'r1',
      senderId: 'd1',
      payload: {'tableNo': 7},
    );
    final y = ProtocolMessage.fromJson(x.toJson());
    expect(y.type, MessageType.orderCreate);
    expect(y.payload['tableNo'], 7);
  });
}
