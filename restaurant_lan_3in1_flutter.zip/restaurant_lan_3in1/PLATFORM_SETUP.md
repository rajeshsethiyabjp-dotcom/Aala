# Platform LAN setup

## Android

Flutter's normal Android template is used. Depending on Android version/OEM, local-network discovery can require Wi-Fi/network permissions. Verify the generated manifest and add the minimum permissions required by the Android SDK target used by your Flutter installation.

## iOS

In `ios/Runner/Info.plist`, add:

```xml
<key>NSLocalNetworkUsageDescription</key>
<string>This app communicates with restaurant devices over the local Wi-Fi network.</string>
<key>NSBonjourServices</key>
<array>
  <string>_restaurant-rms._tcp</string>
</array>
```

Do not add any Internet/cloud service.

## Router

All devices must be on the same LAN/VLAN and client isolation/AP isolation must be disabled. The Billing device must be reachable from other devices on the restaurant Wi-Fi.
