import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/database.dart';
import '../models/entities.dart';
import '../models/protocol.dart';
import '../services/network_manager.dart';
import 'billing_screen.dart';
import 'waiter_screen.dart';
import 'kitchen_screen.dart';

class RestaurantApp extends ConsumerStatefulWidget {
  const RestaurantApp({super.key});
  @override
  ConsumerState<RestaurantApp> createState() => _RestaurantAppState();
}

class _RestaurantAppState extends ConsumerState<RestaurantApp> {
  late final String deviceId;
  late final NetworkManager network;
  String role = 'billing';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    // Device ID is stable for this installation in a real deployment.
    deviceId = DateTime.now().millisecondsSinceEpoch.toString();
    role = 'billing';
    network = NetworkManager(deviceId: deviceId, role: role);

    network.on(MessageType.orderCreate, _onOrderCreate);
    network.on(MessageType.orderStatus, _onOrderStatus);

    await network.startMaster();
    if (mounted) setState(() {});
  }

  Future<void> _onOrderCreate(ProtocolMessage msg) async {
    if (role != 'billing') return;
    final order = RestaurantOrder.fromJson(msg.payload);
    await AppDatabase.instance.saveOrder(order);
    network.broadcast(ProtocolMessage(
      type: MessageType.orderSnapshot,
      requestId: msg.requestId,
      senderId: deviceId,
      payload: order.toJson(),
    ));
  }

  Future<void> _onOrderStatus(ProtocolMessage msg) async {
    if (role != 'billing') return;
    final order = RestaurantOrder.fromJson(msg.payload);
    await AppDatabase.instance.saveOrder(order);
    if (order.status == 'ready') {
      network.send(ProtocolMessage(
        type: MessageType.readyAlert,
        requestId: msg.requestId,
        senderId: deviceId,
        payload: order.toJson(),
      ), targetPeerId: order.waiterDeviceId);
    }
  }

  void _switchRole(String next) {
    setState(() => role = next);
    network.dispose();
    network = NetworkManager(deviceId: deviceId, role: next);
    if (next == 'billing') {
      network.startMaster();
    } else {
      network.startClient();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!mounted) return const SizedBox.shrink();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Restaurant LAN',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange),
        useMaterial3: true,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Restaurant LAN 3-in-1'),
          actions: [
            PopupMenuButton<String>(
              initialValue: role,
              onSelected: _switchRole,
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'billing', child: Text('Billing / Master')),
                PopupMenuItem(value: 'waiter', child: Text('Waiter')),
                PopupMenuItem(value: 'kitchen', child: Text('Kitchen')),
              ],
            ),
          ],
        ),
        body: _body(),
      ),
    );
  }

  Widget _body() {
    switch (role) {
      case 'waiter':
        return WaiterScreen(network: network, deviceId: deviceId);
      case 'kitchen':
        return KitchenScreen(network: network, deviceId: deviceId);
      default:
        return BillingScreen(network: network, deviceId: deviceId);
    }
  }

  @override
  void dispose() {
    network.dispose();
    super.dispose();
  }
}
