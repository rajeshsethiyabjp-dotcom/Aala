import 'dart:async';
import 'package:flutter/material.dart';
import '../data/database.dart';
import '../models/entities.dart';
import '../models/protocol.dart';
import '../services/network_manager.dart';

class KitchenScreen extends StatefulWidget {
  final NetworkManager network;
  final String deviceId;
  const KitchenScreen({super.key, required this.network, required this.deviceId});
  @override
  State<KitchenScreen> createState() => _KitchenScreenState();
}

class _KitchenScreenState extends State<KitchenScreen> {
  List<RestaurantOrder> orders = [];
  StreamSubscription? sub;

  @override
  void initState() {
    super.initState();
    _load();
    widget.network.on(MessageType.orderSnapshot, _onOrder);
  }

  Future<void> _load() async {
    orders = await AppDatabase.instance.openOrders();
    if (mounted) setState(() {});
  }

  Future<void> _onOrder(ProtocolMessage msg) async {
    final o = RestaurantOrder.fromJson(msg.payload);
    await AppDatabase.instance.saveOrder(o);
    await _load();
  }

  Future<void> _status(RestaurantOrder o, String status) async {
    final updated = RestaurantOrder(
      id: o.id, tableNo: o.tableNo, waiterDeviceId: o.waiterDeviceId,
      status: status, createdAt: o.createdAt, updatedAt: DateTime.now(),
      items: o.items,
    );
    await AppDatabase.instance.saveOrder(updated);
    widget.network.send(ProtocolMessage(
      type: MessageType.orderStatus,
      requestId: o.id, senderId: widget.deviceId,
      payload: updated.toJson(),
    ));
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final active = orders.where((o) => o.status != 'paid').toList();
    return GridView.builder(
      padding: const EdgeInsets.all(14),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 430, childAspectRatio: 1.2,
        crossAxisSpacing: 12, mainAxisSpacing: 12,
      ),
      itemCount: active.length,
      itemBuilder: (_, index) {
        final o = active[index];
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text('TABLE ${o.tableNo}', style: Theme.of(context).textTheme.headlineSmall),
                const Spacer(),
                Text(o.createdAt.toLocal().toString().substring(11, 19)),
              ]),
              const Divider(),
              Expanded(child: ListView(
                children: o.items.map((i) => ListTile(
                  dense: true,
                  title: Text('${i.itemName} × ${i.quantity}'),
                  subtitle: Text(i.variantLabel + (i.notes == null ? '' : ' • ${i.notes}')),
                )).toList(),
              )),
              Row(children: [
                Expanded(child: OutlinedButton(
                  onPressed: o.status == 'preparing' ? null : () => _status(o, 'preparing'),
                  child: const Text('Preparing'),
                )),
                const SizedBox(width: 8),
                Expanded(child: FilledButton(
                  onPressed: () => _status(o, 'ready'),
                  child: const Text('ORDER READY'),
                )),
              ]),
            ]),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    sub?.cancel();
    super.dispose();
  }
}
