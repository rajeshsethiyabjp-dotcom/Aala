import 'dart:async';
import 'package:flutter/material.dart';
import '../data/database.dart';
import '../models/entities.dart';
import '../models/protocol.dart';
import '../services/network_manager.dart';

class BillingScreen extends StatefulWidget {
  final NetworkManager network;
  final String deviceId;
  const BillingScreen({super.key, required this.network, required this.deviceId});
  @override
  State<BillingScreen> createState() => _BillingScreenState();
}

class _BillingScreenState extends State<BillingScreen> {
  List<RestaurantOrder> orders = [];
  List<MenuCategory> categories = [];
  List<MenuItem> menu = [];
  StreamSubscription? sub;

  @override
  void initState() {
    super.initState();
    _load();
    widget.network.on(MessageType.orderCreate, _onOrder);
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;
    orders = await db.openOrders();
    categories = await db.categories();
    menu = await db.menu();
    if (mounted) setState(() {});
    _broadcastMenu();
  }

  Future<void> _onOrder(ProtocolMessage msg) async {
    final o = RestaurantOrder.fromJson(msg.payload);
    await AppDatabase.instance.saveOrder(o);
    await _load();
  }

  void _broadcastMenu() {
    widget.network.broadcast(ProtocolMessage(
      type: MessageType.menuSnapshot,
      requestId: DateTime.now().toIso8601String(),
      senderId: widget.deviceId,
      payload: {
        'categories': categories.map((e) => e.toJson()).toList(),
        'items': menu.map((e) => e.toJson()).toList(),
      },
    ));
  }

  Future<void> _markPaid(RestaurantOrder order) async {
    final paid = RestaurantOrder(
      id: order.id, tableNo: order.tableNo,
      waiterDeviceId: order.waiterDeviceId, status: 'paid',
      createdAt: order.createdAt, updatedAt: DateTime.now(),
      items: order.items,
    );
    await AppDatabase.instance.saveOrder(paid);
    widget.network.broadcast(ProtocolMessage(
      type: MessageType.orderSnapshot,
      requestId: DateTime.now().toIso8601String(),
      senderId: widget.deviceId,
      payload: paid.toJson(),
    ));
    await _load();
  }

  Future<void> _addCategory() async {
    final c = await _textDialog('Category name');
    if (c == null || c.trim().isEmpty) return;
    final category = MenuCategory(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: c.trim(), sortOrder: categories.length, active: true,
    );
    final all = [...categories, category];
    await AppDatabase.instance.replaceMenu(all, menu);
    await _load();
  }

  Future<void> _addItem() async {
    if (categories.isEmpty) {
      await _addCategory();
      if (categories.isEmpty) return;
    }
    final name = await _textDialog('Item name');
    if (name == null || name.trim().isEmpty) return;
    final priceText = await _textDialog('Regular price (₹)');
    final price = int.tryParse(priceText ?? '');
    if (price == null) return;
    final item = MenuItem(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      categoryId: categories.first.id, name: name.trim(), active: true,
      variants: [
        PriceVariant(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          label: 'Regular', pricePaise: price * 100,
        )
      ],
    );
    await AppDatabase.instance.replaceMenu(categories, [...menu, item]);
    await _load();
  }

  Future<String?> _textDialog(String title) async {
    final controller = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(controller: controller, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Save')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            Expanded(child: Text('Running Orders', style: Theme.of(context).textTheme.headlineSmall)),
            FilledButton.icon(onPressed: _addCategory, icon: const Icon(Icons.category), label: const Text('Category')),
            const SizedBox(width: 8),
            FilledButton.icon(onPressed: _addItem, icon: const Icon(Icons.restaurant_menu), label: const Text('Item')),
          ]),
          const SizedBox(height: 12),
          ...orders.map((o) => Card(
            child: ExpansionTile(
              title: Text('Table ${o.tableNo}  •  ₹${(o.totalPaise/100).toStringAsFixed(2)}'),
              subtitle: Text('${o.status.toUpperCase()} • ${o.items.length} line(s)'),
              children: [
                for (final i in o.items)
                  ListTile(
                    title: Text('${i.itemName} — ${i.variantLabel} × ${i.quantity}'),
                    subtitle: i.notes == null ? null : Text(i.notes!),
                    trailing: Text('₹${(i.totalPaise/100).toStringAsFixed(2)}'),
                  ),
                if (o.status != 'paid')
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: FilledButton(
                      onPressed: () => _markPaid(o),
                      child: const Text('Generate Final Bill / Mark Paid'),
                    ),
                  ),
              ],
            ),
          )),
          const Divider(height: 32),
          Text('Menu', style: Theme.of(context).textTheme.headlineSmall),
          ...menu.map((i) => ListTile(
            title: Text(i.name),
            subtitle: Text(i.variants.map((v) => '${v.label}: ₹${v.pricePaise/100}').join('  •  ')),
          )),
        ],
      ),
    );
  }

  @override
  void dispose() {
    sub?.cancel();
    super.dispose();
  }
}
