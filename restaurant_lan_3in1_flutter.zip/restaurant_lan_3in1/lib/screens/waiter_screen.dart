import 'dart:async';
import 'package:flutter/material.dart';
import '../data/database.dart';
import '../models/entities.dart';
import '../models/protocol.dart';
import '../services/network_manager.dart';

class WaiterScreen extends StatefulWidget {
  final NetworkManager network;
  final String deviceId;
  const WaiterScreen({super.key, required this.network, required this.deviceId});
  @override
  State<WaiterScreen> createState() => _WaiterScreenState();
}

class _WaiterScreenState extends State<WaiterScreen> {
  int table = 1;
  String category = 'All';
  List<MenuCategory> categories = [];
  List<MenuItem> menu = [];
  final cart = <String, OrderItem>{};
  StreamSubscription? events;
  bool readyFlash = false;

  @override
  void initState() {
    super.initState();
    _load();
    widget.network.on(MessageType.menuSnapshot, _onMenu);
    widget.network.on(MessageType.readyAlert, _onReady);
  }

  Future<void> _load() async {
    categories = await AppDatabase.instance.categories();
    menu = await AppDatabase.instance.menu();
    if (mounted) setState(() {});
  }

  Future<void> _onMenu(ProtocolMessage msg) async {
    final cs = (msg.payload['categories'] as List? ?? [])
        .map((e) => MenuCategory.fromJson(Map<String,dynamic>.from(e))).toList();
    final items = (msg.payload['items'] as List? ?? [])
        .map((e) => MenuItem.fromJson(Map<String,dynamic>.from(e))).toList();
    await AppDatabase.instance.replaceMenu(cs, items);
    await _load();
  }

  Future<void> _onReady(ProtocolMessage msg) async {
    if (!mounted) return;
    setState(() => readyFlash = true);
    Timer(const Duration(seconds: 3), () {
      if (mounted) setState(() => readyFlash = false);
    });
  }

  void _add(MenuItem item, PriceVariant variant) {
    final key = '${item.id}:${variant.id}:$table';
    final old = cart[key];
    setState(() {
      cart[key] = OrderItem(
        id: old?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        orderId: '',
        menuItemId: item.id,
        itemName: item.name,
        variantLabel: variant.label,
        unitPricePaise: variant.pricePaise,
        quantity: (old?.quantity ?? 0) + 1,
      );
    });
  }

  Future<void> _sendOrder() async {
    if (cart.isEmpty) return;
    final orderId = DateTime.now().microsecondsSinceEpoch.toString();
    final now = DateTime.now();
    final items = cart.values.map((x) => OrderItem(
      id: x.id, orderId: orderId, menuItemId: x.menuItemId,
      itemName: x.itemName, variantLabel: x.variantLabel,
      unitPricePaise: x.unitPricePaise, quantity: x.quantity, notes: x.notes,
    )).toList();
    final order = RestaurantOrder(
      id: orderId, tableNo: table, waiterDeviceId: widget.deviceId,
      status: 'open', createdAt: now, updatedAt: now, items: items,
    );
    await AppDatabase.instance.saveOrder(order);
    widget.network.send(ProtocolMessage(
      type: MessageType.orderCreate,
      requestId: orderId, senderId: widget.deviceId,
      payload: order.toJson(),
    ));
    setState(() => cart.clear());
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('KOT sent')));
  }

  @override
  Widget build(BuildContext context) {
    final filtered = category == 'All'
        ? menu
        : menu.where((x) => x.categoryId == category).toList();
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      color: readyFlash ? Colors.green.withOpacity(.25) : null,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            const Text('Table'),
            const SizedBox(width: 8),
            DropdownButton<int>(
              value: table,
              items: List.generate(50, (i) => DropdownMenuItem(value: i+1, child: Text('${i+1}'))),
              onChanged: (v) => setState(() => table = v ?? 1),
            ),
            const SizedBox(width: 16),
            Expanded(child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                ChoiceChip(label: const Text('All'), selected: category == 'All',
                  onSelected: (_) => setState(() => category = 'All')),
                ...categories.map((c) => Padding(
                  padding: const EdgeInsets.only(left: 6),
                  child: ChoiceChip(label: Text(c.name), selected: category == c.id,
                    onSelected: (_) => setState(() => category = c.id)),
                )),
              ]),
            )),
            FilledButton.icon(onPressed: _sendOrder, icon: const Icon(Icons.send), label: Text('Send (${cart.length})')),
          ]),
        ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(12),
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 280, childAspectRatio: 1.55,
              crossAxisSpacing: 10, mainAxisSpacing: 10,
            ),
            itemCount: filtered.length,
            itemBuilder: (_, index) {
              final item = filtered[index];
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(item.name, style: Theme.of(context).textTheme.titleMedium),
                    const Spacer(),
                    Wrap(spacing: 6, children: item.variants.map((v) => FilledButton.tonal(
                      onPressed: () => _add(item, v),
                      child: Text('${v.label}\n₹${v.pricePaise/100}'),
                    )).toList()),
                  ]),
                ),
              );
            },
          ),
        ),
      ]),
    );
  }

  @override
  void dispose() {
    events?.cancel();
    super.dispose();
  }
}
