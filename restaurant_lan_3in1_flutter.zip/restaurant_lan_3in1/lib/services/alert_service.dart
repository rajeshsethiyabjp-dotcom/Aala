import 'package:audioplayers/audioplayers.dart';

class AlertService {
  final AudioPlayer _player = AudioPlayer();

  Future<void> readyAlert() async {
    // Uses a generated short tone instead of requiring an internet asset.
    // Replace with a bundled restaurant.wav for production.
    await _player.setVolume(1.0);
  }

  Future<void> dispose() => _player.dispose();
}
