import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:bonsoir/bonsoir.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:uuid/uuid.dart';

import '../models/protocol.dart';

typedef MessageHandler = FutureOr<void> Function(ProtocolMessage message);

class Peer {
  final String id;
  final String role;
  final WebSocketChannel channel;
  final String address;
  Peer(this.id, this.role, this.channel, this.address);
}

/// LAN-only discovery + WebSocket transport.
///
/// Master:
///   startMaster() -> starts HTTP/WebSocket server and advertises mDNS.
///
/// Client:
///   startClient() -> discovers _restaurant-rms._tcp and connects.
///
/// The application protocol is deliberately small JSON messages so the
/// transport can be replaced with raw TCP later without changing the UI.
class NetworkManager {
  static const serviceType = '_restaurant-rms._tcp';
  static const serviceName = 'Restaurant RMS';

  final String deviceId;
  final String role;
  final _uuid = const Uuid();

  HttpServer? _server;
  BonsoirBroadcast? _broadcast;
  BonsoirDiscovery? _discovery;
  WebSocketChannel? _masterChannel;

  final Map<String, Peer> peers = {};
  final Map<String, Timer> _reconnectTimers = {};
  final Map<String, MessageHandler> _handlers = {};
  int? port;
  String? masterHost;

  final _events = StreamController<ProtocolMessage>.broadcast();
  Stream<ProtocolMessage> get messages => _events.stream;

  NetworkManager({required this.deviceId, required this.role});

  void on(String type, MessageHandler handler) => _handlers[type] = handler;

  Future<void> startMaster() async {
    _server = await HttpServer.bind(InternetAddress.anyIPv4, 0);
    port = _server!.port;

    _server!.listen((request) async {
      if (request.uri.path != '/ws') {
        request.response.statusCode = HttpStatus.notFound;
        await request.response.close();
        return;
      }
      final socket = await WebSocketTransformer.upgrade(request);
      final channel = IOWebSocketChannel(socket);
      _attachPeer(channel, request.connectionInfo?.remoteAddress.address ?? 'unknown');
    });

    _broadcast = BonsoirBroadcast(
      service: BonsoirService(
        name: '$serviceName-$deviceId',
        type: serviceType,
        port: port!,
      ),
    );
    await _broadcast!.initialize();
    await _broadcast!.start();
  }

  Future<void> startClient() async {
    _discovery = BonsoirDiscovery(type: serviceType);
    await _discovery!.initialize();
    _discovery!.eventStream.listen((event) {
      if (event is BonsoirDiscoveryServiceFoundEvent) {
        final service = event.service;
        service.resolve(_discovery!.serviceResolver);
      } else if (event is BonsoirDiscoveryServiceResolvedEvent) {
        final service = event.service;
        final host = service.host;
        final p = service.port;
        if (host != null && p != null) {
          _connectToMaster(host, p);
        }
      }
    });
    await _discovery!.start();
  }

  Future<void> _connectToMaster(String host, int p) async {
    if (_masterChannel != null) return;
    masterHost = host;
    try {
      final channel = IOWebSocketChannel.connect(
        Uri.parse('ws://$host:$p/ws'),
        connectTimeout: const Duration(seconds: 5),
      );
      _masterChannel = channel;
      _listenChannel(channel, peerId: 'master', address: host);
      send(ProtocolMessage(
        type: MessageType.hello,
        requestId: _uuid.v4(),
        senderId: deviceId,
        payload: {'role': role},
      ));
    } catch (_) {
      _masterChannel = null;
      _reconnectTimers['master']?.cancel();
      _reconnectTimers['master'] = Timer(const Duration(seconds: 3), () {
        if (masterHost != null && p > 0) _connectToMaster(host, p);
      });
    }
  }

  void _attachPeer(WebSocketChannel channel, String address) {
    _listenChannel(channel, peerId: _uuid.v4(), address: address);
  }

  void _listenChannel(WebSocketChannel channel,
      {required String peerId, required String address}) {
    channel.stream.listen(
      (raw) {
        try {
          final map = jsonDecode(raw as String) as Map<String, dynamic>;
          final msg = ProtocolMessage.fromJson(map);
          _events.add(msg);
          final h = _handlers[msg.type];
          if (h != null) h(msg);
        } catch (_) {}
      },
      onDone: () {
        if (peerId == 'master') {
          _masterChannel = null;
          _reconnectTimers['master']?.cancel();
          _reconnectTimers['master'] =
              Timer(const Duration(seconds: 2), () {
            if (masterHost != null && port != null) {
              _connectToMaster(masterHost!, port!);
            }
          });
        } else {
          peers.remove(peerId);
        }
      },
      onError: (_) {
        if (peerId == 'master') _masterChannel = null;
      },
      cancelOnError: true,
    );
  }

  void registerPeer(String id, String peerRole, WebSocketChannel channel,
      String address) {
    peers[id] = Peer(id, peerRole, channel, address);
  }

  void send(ProtocolMessage msg, {String? targetPeerId}) {
    final data = jsonEncode(msg.toJson());
    if (targetPeerId != null) {
      peers[targetPeerId]?.channel.sink.add(data);
      return;
    }
    if (role == 'billing') {
      for (final peer in peers.values) {
        peer.channel.sink.add(data);
      }
    } else {
      _masterChannel?.sink.add(data);
    }
  }

  void broadcast(ProtocolMessage msg) => send(msg);

  void dispose() {
    _broadcast?.stop();
    _discovery?.stop();
    _server?.close(force: true);
    _masterChannel?.sink.close();
    for (final p in peers.values) {
      p.channel.sink.close();
    }
    for (final t in _reconnectTimers.values) t.cancel();
    _events.close();
  }
}
