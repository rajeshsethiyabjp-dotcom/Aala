class MenuCategory {
  final String id;
  final String name;
  final int sortOrder;
  final bool active;

  const MenuCategory({
    required this.id,
    required this.name,
    required this.sortOrder,
    required this.active,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'sortOrder': sortOrder, 'active': active,
  };

  factory MenuCategory.fromJson(Map<String, dynamic> j) => MenuCategory(
    id: j['id'] as String,
    name: j['name'] as String,
    sortOrder: (j['sortOrder'] ?? 0) as int,
    active: (j['active'] ?? 1) == 1 || j['active'] == true,
  );
}

class MenuItem {
  final String id;
  final String categoryId;
  final String name;
  final String? notes;
  final bool active;
  final List<PriceVariant> variants;

  const MenuItem({
    required this.id,
    required this.categoryId,
    required this.name,
    this.notes,
    required this.active,
    required this.variants,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'categoryId': categoryId, 'name': name,
    'notes': notes, 'active': active,
    'variants': variants.map((e) => e.toJson()).toList(),
  };

  factory MenuItem.fromJson(Map<String, dynamic> j) => MenuItem(
    id: j['id'] as String,
    categoryId: j['categoryId'] as String,
    name: j['name'] as String,
    notes: j['notes'] as String?,
    active: j['active'] == true || j['active'] == 1,
    variants: ((j['variants'] ?? []) as List)
        .map((e) => PriceVariant.fromJson(Map<String, dynamic>.from(e)))
        .toList(),
  );
}

class PriceVariant {
  final String id;
  final String label;
  final int pricePaise;

  const PriceVariant({
    required this.id,
    required this.label,
    required this.pricePaise,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'label': label, 'pricePaise': pricePaise,
  };

  factory PriceVariant.fromJson(Map<String, dynamic> j) => PriceVariant(
    id: j['id'] as String,
    label: j['label'] as String,
    pricePaise: j['pricePaise'] as int,
  );
}

enum OrderStatus { open, preparing, ready, paid, cancelled }

class OrderItem {
  final String id;
  final String orderId;
  final String menuItemId;
  final String itemName;
  final String variantLabel;
  final int unitPricePaise;
  final int quantity;
  final String? notes;

  const OrderItem({
    required this.id,
    required this.orderId,
    required this.menuItemId,
    required this.itemName,
    required this.variantLabel,
    required this.unitPricePaise,
    required this.quantity,
    this.notes,
  });

  int get totalPaise => unitPricePaise * quantity;

  Map<String, dynamic> toJson() => {
    'id': id, 'orderId': orderId, 'menuItemId': menuItemId,
    'itemName': itemName, 'variantLabel': variantLabel,
    'unitPricePaise': unitPricePaise, 'quantity': quantity, 'notes': notes,
  };

  factory OrderItem.fromJson(Map<String, dynamic> j) => OrderItem(
    id: j['id'] as String,
    orderId: j['orderId'] as String,
    menuItemId: j['menuItemId'] as String,
    itemName: j['itemName'] as String,
    variantLabel: j['variantLabel'] as String,
    unitPricePaise: j['unitPricePaise'] as int,
    quantity: j['quantity'] as int,
    notes: j['notes'] as String?,
  );
}

class RestaurantOrder {
  final String id;
  final int tableNo;
  final String waiterDeviceId;
  final String status;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<OrderItem> items;

  const RestaurantOrder({
    required this.id,
    required this.tableNo,
    required this.waiterDeviceId,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    required this.items,
  });

  int get totalPaise => items.fold(0, (s, x) => s + x.totalPaise);

  Map<String, dynamic> toJson() => {
    'id': id, 'tableNo': tableNo, 'waiterDeviceId': waiterDeviceId,
    'status': status, 'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
    'items': items.map((e) => e.toJson()).toList(),
  };

  factory RestaurantOrder.fromJson(Map<String, dynamic> j) => RestaurantOrder(
    id: j['id'] as String,
    tableNo: j['tableNo'] as int,
    waiterDeviceId: j['waiterDeviceId'] as String,
    status: j['status'] as String,
    createdAt: DateTime.parse(j['createdAt'] as String),
    updatedAt: DateTime.parse(j['updatedAt'] as String),
    items: ((j['items'] ?? []) as List)
        .map((e) => OrderItem.fromJson(Map<String, dynamic>.from(e)))
        .toList(),
  );
}
