class ProtocolMessage {
  final String type;
  final String requestId;
  final String senderId;
  final Map<String, dynamic> payload;

  const ProtocolMessage({
    required this.type,
    required this.requestId,
    required this.senderId,
    required this.payload,
  });

  Map<String, dynamic> toJson() => {
    'type': type,
    'requestId': requestId,
    'senderId': senderId,
    'payload': payload,
  };

  factory ProtocolMessage.fromJson(Map<String, dynamic> j) => ProtocolMessage(
    type: j['type'] as String,
    requestId: j['requestId'] as String? ?? '',
    senderId: j['senderId'] as String? ?? '',
    payload: Map<String, dynamic>.from(j['payload'] ?? {}),
  );
}

abstract final class MessageType {
  static const hello = 'hello';
  static const menuSnapshot = 'menu.snapshot';
  static const orderCreate = 'order.create';
  static const orderSnapshot = 'order.snapshot';
  static const orderStatus = 'order.status';
  static const readyAlert = 'order.ready.alert';
  static const ping = 'ping';
  static const pong = 'pong';
}
