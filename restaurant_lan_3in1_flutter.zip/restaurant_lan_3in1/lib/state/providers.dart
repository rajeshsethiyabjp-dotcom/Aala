import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../data/database.dart';
import '../models/entities.dart';
import '../models/protocol.dart';
import '../services/network_manager.dart';

final databaseProvider = Provider((ref) => AppDatabase.instance);

final deviceIdProvider = Provider<String>((ref) {
  throw UnimplementedError('Initialized in app bootstrap');
});

final roleProvider = StateProvider<String>((ref) => 'billing');

final networkProvider = Provider<NetworkManager>((ref) {
  throw UnimplementedError('Initialized in app bootstrap');
});

final menuProvider = FutureProvider<List<MenuItem>>((ref) async {
  return ref.read(databaseProvider).menu();
});

final categoriesProvider = FutureProvider<List<MenuCategory>>((ref) async {
  return ref.read(databaseProvider).categories();
});

final openOrdersProvider = FutureProvider<List<RestaurantOrder>>((ref) async {
  return ref.read(databaseProvider).openOrders();
});

final appBootstrapProvider = FutureProvider<void>((ref) async {
  final prefs = await SharedPreferences.getInstance();
  var id = prefs.getString('device_id');
  if (id == null) {
    id = const Uuid().v4();
    await prefs.setString('device_id', id);
  }
  ref.container.read(roleProvider.notifier).state =
      prefs.getString('role') ?? 'billing';
});
