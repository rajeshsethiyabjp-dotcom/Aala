import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/entities.dart';

class AppDatabase {
  static final AppDatabase instance = AppDatabase._();
  AppDatabase._();

  Database? _db;

  Future<Database> get db async {
    _db ??= await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'restaurant_lan.sqlite');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE categories(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            sort_order INTEGER NOT NULL DEFAULT 0,
            active INTEGER NOT NULL DEFAULT 1
          )
        ''');
        await db.execute('''
          CREATE TABLE menu_items(
            id TEXT PRIMARY KEY,
            category_id TEXT NOT NULL,
            name TEXT NOT NULL,
            notes TEXT,
            active INTEGER NOT NULL DEFAULT 1
          )
        ''');
        await db.execute('''
          CREATE TABLE price_variants(
            id TEXT PRIMARY KEY,
            menu_item_id TEXT NOT NULL,
            label TEXT NOT NULL,
            price_paise INTEGER NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE orders(
            id TEXT PRIMARY KEY,
            table_no INTEGER NOT NULL,
            waiter_device_id TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE order_items(
            id TEXT PRIMARY KEY,
            order_id TEXT NOT NULL,
            menu_item_id TEXT NOT NULL,
            item_name TEXT NOT NULL,
            variant_label TEXT NOT NULL,
            unit_price_paise INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            notes TEXT
          )
        ''');
      },
    );
  }

  Future<List<MenuCategory>> categories() async {
    final d = await db;
    final rows = await d.query('categories', orderBy: 'sort_order, name');
    return rows.map((r) => MenuCategory(
      id: r['id'] as String, name: r['name'] as String,
      sortOrder: r['sort_order'] as int, active: r['active'] == 1,
    )).toList();
  }

  Future<List<MenuItem>> menu() async {
    final d = await db;
    final items = await d.query('menu_items', where: 'active=1', orderBy: 'name');
    final out = <MenuItem>[];
    for (final r in items) {
      final variants = await d.query('price_variants',
          where: 'menu_item_id=?', whereArgs: [r['id']]);
      out.add(MenuItem(
        id: r['id'] as String,
        categoryId: r['category_id'] as String,
        name: r['name'] as String,
        notes: r['notes'] as String?,
        active: r['active'] == 1,
        variants: variants.map((v) => PriceVariant(
          id: v['id'] as String, label: v['label'] as String,
          pricePaise: v['price_paise'] as int,
        )).toList(),
      ));
    }
    return out;
  }

  Future<void> replaceMenu(
    List<MenuCategory> categories,
    List<MenuItem> items,
  ) async {
    final d = await db;
    await d.transaction((txn) async {
      await txn.delete('price_variants');
      await txn.delete('menu_items');
      await txn.delete('categories');
      for (final c in categories) {
        await txn.insert('categories', {
          'id': c.id, 'name': c.name, 'sort_order': c.sortOrder,
          'active': c.active ? 1 : 0,
        });
      }
      for (final i in items) {
        await txn.insert('menu_items', {
          'id': i.id, 'category_id': i.categoryId, 'name': i.name,
          'notes': i.notes, 'active': i.active ? 1 : 0,
        });
        for (final v in i.variants) {
          await txn.insert('price_variants', {
            'id': v.id, 'menu_item_id': i.id, 'label': v.label,
            'price_paise': v.pricePaise,
          });
        }
      }
    });
  }

  Future<void> saveOrder(RestaurantOrder o) async {
    final d = await db;
    await d.transaction((txn) async {
      await txn.insert('orders', {
        'id': o.id, 'table_no': o.tableNo,
        'waiter_device_id': o.waiterDeviceId, 'status': o.status,
        'created_at': o.createdAt.toIso8601String(),
        'updated_at': o.updatedAt.toIso8601String(),
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      await txn.delete('order_items', where: 'order_id=?', whereArgs: [o.id]);
      for (final i in o.items) {
        await txn.insert('order_items', {
          ...i.toJson(),
        });
      }
    });
  }

  Future<List<RestaurantOrder>> openOrders() async {
    final d = await db;
    final rows = await d.query('orders',
      where: "status != 'paid' AND status != 'cancelled'",
      orderBy: 'created_at DESC');
    final out = <RestaurantOrder>[];
    for (final r in rows) {
      final items = await d.query('order_items',
          where: 'order_id=?', whereArgs: [r['id']]);
      out.add(RestaurantOrder(
        id: r['id'] as String, tableNo: r['table_no'] as int,
        waiterDeviceId: r['waiter_device_id'] as String,
        status: r['status'] as String,
        createdAt: DateTime.parse(r['created_at'] as String),
        updatedAt: DateTime.parse(r['updated_at'] as String),
        items: items.map((x) => OrderItem.fromJson(Map<String, dynamic>.from(x))).toList(),
      ));
    }
    return out;
  }
}
