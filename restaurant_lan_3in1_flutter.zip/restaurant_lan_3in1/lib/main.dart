import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'screens/app.dart';
import 'state/providers.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final container = ProviderContainer();
  await container.read(appBootstrapProvider.future);
  runApp(
    UncontrolledProviderScope(
      container: container,
      child: const RestaurantApp(),
    ),
  );
}
