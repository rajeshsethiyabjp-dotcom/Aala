# Restaurant LAN 3-in-1

Offline-first Flutter restaurant management system for a single local Wi-Fi/LAN.

## Roles
- **Billing / Master**: owns the authoritative SQLite database, runs a local WebSocket server, manages menu, orders and payments.
- **Waiter / Client**: discovers Master over mDNS, receives menu snapshots, punches orders, receives ready alerts.
- **Kitchen / Client**: discovers Master, receives KOTs, updates Preparing/Ready, and sends the ready event to the specific waiter.

## Network model

```text
                    Local Wi-Fi / LAN
                         |
              +----------+----------+
              |                     |
       Billing / Master       Waiter / Kitchen
       SQLite + WS server       WS clients
              |
        mDNS advertisement
        _restaurant-rms._tcp
```

No cloud API, Firebase, REST internet dependency, or external server is used.

## Important production notes

1. Android/iOS must be allowed to use the local network. On iOS add `NSLocalNetworkUsageDescription` and the Bonjour service type to `Info.plist`.
2. Android 13+ Wi-Fi discovery may require appropriate network permissions depending on OEM/OS behavior. Test on the actual restaurant router.
3. The included `NetworkManager` uses Bonsoir for mDNS service discovery/advertising and WebSockets for transport.
4. The Master is authoritative. Clients persist a local copy of the menu and last-known orders so the UI remains usable during a brief disconnect.
5. For a production deployment, add authentication/pairing (restaurant PIN or one-time pairing code), encrypted application payloads, audit logging, database migrations, crash logging, printer integration, and a watchdog/service strategy for the Billing device.
6. This project intentionally does not require Internet access.

## Run

```bash
flutter pub get
flutter run
```

On first launch choose:
- Billing / Master
- Waiter
- Kitchen

Run Billing first on the restaurant's tablet/phone. The other devices will discover it automatically.

## Protocol

Messages are JSON envelopes:

```json
{
  "type": "menu.snapshot",
  "requestId": "...",
  "senderId": "...",
  "payload": {}
}
```

See `lib/models/protocol.dart`.

## Extending

- Add thermal ESC/POS printing behind a `PrinterService`.
- Add GST/tax configuration to `orders`/`order_items`.
- Add user authentication and per-waiter identity.
- Add table occupancy/merge/split.
- Add kitchen stations by `category.station`.
